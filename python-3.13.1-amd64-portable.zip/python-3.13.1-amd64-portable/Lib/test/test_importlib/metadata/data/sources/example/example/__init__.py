def main():
    return 'example'
