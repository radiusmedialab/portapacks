from __future__ import annotations

def foo(a, b, c):  pass
